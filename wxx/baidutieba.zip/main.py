import pandas as pd
import requests
import re
from bs4 import BeautifulSoup

# 发送HTTP请求获取网页内容
url = 'https://tieba.baidu.com/hottopic/browse/topicList?res_type=1&qq-pf-to=pcqq.c2c'
res = requests.get(url=url)

picture_url=[]#热搜封面图
position_list = []  # 热搜排名
title_list = []  # 热搜标题
hot_value_list = []  # 热度值
hot_url = []  # 热搜链接
introduction_list=[] #简介


def extract_number_from_string(text):
    match = re.search(r'(\d+(\.\d+)?)w', text, re.IGNORECASE)

    if match:
        number_str = match.group(1)
        number = float(number_str)
        number *= 10000  # 将 'w' 转换为万
        return int(number)
    else:
        return None

soup = BeautifulSoup(res.text, 'html.parser')
#print(soup.prettify())
position=0
for topic in soup.find_all('li'):
    #标题
    title=topic.find('a',class_='topic-text').get_text()
    title_list.append(title)
    #热搜链接
    hot=topic.find('a',class_='topic-text')['href']
    hot_url.append(hot)
    #封面连接
    picture=topic.find('img',class_='topic-cover')['src']
    picture_url.append(picture)
    #简介
    Introduction=topic.find('p',class_='topic-top-item-desc').get_text()
    introduction_list.append(Introduction)
    #热度值
    hot_value_text=topic.find('span',class_='topic-num').text.strip()
    hot_value=extract_number_from_string(hot_value_text)
    hot_value_list.append(hot_value)
    #排名
    position+=1
    position_list.append(position)

df = pd.DataFrame(
    {
        '热搜排名': position_list,
        '热搜标题': title_list,
        '简介':introduction_list,
        '热度值': hot_value_list,
        '热搜链接': hot_url,
        '热搜封面': picture_url
    }
)
# 保存结果到csv文件
df.to_csv('百度贴吧热搜.csv', index=False, encoding='utf_8_sig')
