import pandas as pd
import requests
import re
from bs4 import BeautifulSoup

url = 'https://tophub.today/n/L4MdA5ldxD'
headers={
    'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36 SLBrowser/9.0.0.10191 SLBChan/103',
    'cookie':'Hm_lvt_3b1e939f6e789219d8629de8a519eab9=1699864680,1700051244; Hm_lpvt_3b1e939f6e789219d8629de8a519eab9=1700051365',
    'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-encoding':'gzip, deflate, br',
    'accept-language':'zh-CN,zh;q=0.9',
    'cache-control':'max-age=0',
    'cache-control':'max-age=0'
}
res = requests.get(url=url,headers=headers)

picture_url=[]#热搜封面图
position_list = []  # 热搜排名
title_list = []  # 热搜标题
hot_value_list = []  # 热度值
hot_url = []  # 热搜链接
introduction_list=[] #简介


def extract_number_from_string(text):
    match = re.search(r'(\d+(\.\d+)?)万', text, re.IGNORECASE)

    if match:
        number_str = match.group(1)
        number = float(number_str)
        number *= 10000  # 将 'w' 转换为万
        return int(number)
    else:
        return None

soup = BeautifulSoup(res.text, 'html.parser')
print(soup.prettify())
position=0
for topic in soup.find_all('tr'):
    #标题
    title=topic.find('a').get_text()
    title_list.append(title)
    print(title)
    #热搜链接
    hot='https://tophub.today'+topic.find('a')['href']
    hot_url.append(hot)
    print(hot)
    #热度值
    hot_value_text=topic.find('td', text=re.compile(r'\d+\.\d+万'))
    hot_value = re.search(r'(\d+\.\d+)万', hot_value_text.text)
    hot_value_str=hot_value.group(1)
    hot_value_number=float(hot_value_str)*10000
    print(hot_value_number)
    hot_value_list.append(hot_value_number)
    #排名
    position+=1
    position_list.append(position)
    if position>=10:
        break

df = pd.DataFrame(
    {
        '热搜排名': position_list,
        '热搜标题': title_list,
        '热度值': hot_value_list,
        '热搜链接': hot_url,
    }
)
# 保存结果到csv文件
df.to_csv('小红书热搜.csv', index=False, encoding='utf_8_sig')

