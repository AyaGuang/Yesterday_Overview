// pages/yestoday/yestoday.js
Page({

    data: {
        search_txt:"",
        imageUrls: [
            'http://picnew7.photophoto.cn/20130517/qiutiandeshulintupian-11483850_1.jpg','http://picnew7.photophoto.cn/20130517/qiutiandeshulintupian-11483850_1.jpg','http://picnew7.photophoto.cn/20130517/qiutiandeshulintupian-11483850_1.jpg'
        ],
        currentIndex: 0
    },
    swiperChange: function (e) {
        this.setData({
          currentIndex: e.detail.current
        });
    },
    get_search:function(e) {
        var inputValue=e.detail.value;
        this.setData({search_txt:inputValue});
    },
    test:function () {
        console.log(this.data.currentIndex);
    },
    onLoad(options) {

    },
    onReady() {

    },
    onShow() {

    },


    onHide() {

    },

    onUnload() {

    },

    onPullDownRefresh() {

    },
    onReachBottom() {

    },

    onShareAppMessage() {

    }
})