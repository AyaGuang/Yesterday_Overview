// pages/bdtb/bdtb.js
Page({
    data: {
        showBottomPopup: false,
        items: [
            { imageSrc: 'https://i2.hdslb.com/bfs/archive/682e2656beb92cc606b1cc48583cb2f6803cd8ce.jpg@412w_232h_1c_!web-popular.avif', textContent: '刚来法国时帮过我的老太太成了homeless…',_url:'https://www.bilibili.com/video/BV1ju4y1N7od',pageview:"265.1万",writer:"江酱的法语日记"},
            { imageSrc: 'https://i0.hdslb.com/bfs/archive/70aecd707c9b9f12bc6c10b8143280fb5599c84d.jpg@412w_232h_1c_!web-popular.avif', textContent: '大师撤回了一次行骗',_url:'https://www.bilibili.com/video/BV1vc411X7Lc',pageview:"344.2万",writer:"-显眼宝-"},
            { imageSrc: 'https://i2.hdslb.com/bfs/archive/34816bbb0a97ae216a4adbca444f96e13ffb2027.jpg@412w_232h_1c_!web-popular.avif', textContent: '小朋友：教练我长得让你恶心吗。',_url:'https://www.bilibili.com/video/BV1oC4y17786',pageview:"270.5万",writer:"笨小海涛"},
            { imageSrc: 'https://i2.hdslb.com/bfs/archive/53a46b86657f25b5ddca81fdd81e41c0590faa03.jpg@412w_232h_1c_!web-popular.avif', textContent: '这辣白菜第一了',_url:'https://www.bilibili.com/video/BV1ZG411Q7er',pageview:"257.4万",writer:"八零徐姥姥"},
            { imageSrc: 'https://i0.hdslb.com/bfs/archive/a7d65b51106e42e74db2753ae59898193b8ab8c8.jpg@412w_232h_1c_!web-popular.avif', textContent: '在毛毯上薅出艾伦',_url:'https://www.bilibili.com/video/BV1X94y137YV',pageview:"126.5万",writer:"咖喱芋圆儿花开富贵儿"},
            { imageSrc: 'https://i0.hdslb.com/bfs/archive/e1f8fa48601ee00cd51232c0a88e15c453844bf2.jpg@412w_232h_1c_!web-popular.avif', textContent: '【医学博士】得了破伤风还能活多久？| 这种伤口很有可能是破伤风！',_url:'https://www.bilibili.com/video/BV1Fu4y1b7Ls',pageview:"150万",writer:"兔叭咯"},
            { imageSrc: 'https://i1.hdslb.com/bfs/archive/40d16c167f3fea72a68712cdc421ba087a83a7d2.jpg@412w_232h_1c_!web-popular.avif', textContent: '能给人急死',_url:'https://www.bilibili.com/video/BV1nj411a7Cz',pageview:"249.6万",writer:"高斯Goh"},
            { imageSrc: 'https://i1.hdslb.com/bfs/archive/9be462dc39e39b3f5ca490e3a7f46775932f1f6b.jpg@412w_232h_1c_!web-popular.avif', textContent: '复刻全球最受欢迎炸鸡，每年卖出上亿份，到底有多好吃？',_url:'https://www.bilibili.com/video/BV1aM411D7g5',pageview:"215.4万",writer:"大碗拿铁"},
            { imageSrc: 'https://i2.hdslb.com/bfs/archive/1c2c9c3a59d562be330ede9ca30146374e163549.jpg@412w_232h_1c_!web-popular.avif', textContent: '大连一座让人生活惬意的城市，每个人在这都值得无忧无虑。',_url:'https://www.bilibili.com/video/BV1uj411a7xW',pageview:"216.7万",writer:"superB太"},
            { imageSrc: 'https://i1.hdslb.com/bfs/archive/a5413460c9137476f569612bfefc3e43181cf17a.jpg@412w_232h_1c_!web-popular.avif', textContent: '当电诈分子遇到开挂保安',_url:'https://www.bilibili.com/video/BV1xj411h72w',pageview:"214.1万",writer:"薪儿姐师尊"},
          ],
          selectedIndex: -1,
          selectedItem:[]
      },
        // 点击按钮显示底部小界面
    showBottomPopup: function (event) {
        const index = event.currentTarget.dataset.index;
        const selectedItem = this.data.items[index];
        this.setData({
        showBottomPopup: true,
        selectedIndex: index, 
        selectedItem:selectedItem,
        });
    },
    hideBottomPopup: function () {
        this.setData({
          showBottomPopup: false,
        selectedIndex: -1, // 重置 selectedIndex
        selectedItem: {}, // 重置选中的项数据
        });
      },
      copyUrl: function () {
        const url = this.data.selectedItem._url;
    
        wx.setClipboardData({
          data: url,
          success: function (res) {
            wx.showToast({
              title: '链接已复制',
              icon: 'success',
            });
          },
          fail: function (res) {
            wx.showToast({
              title: '复制失败',
              icon: 'none',
            });
          },
        });
      },  
      copyTitle: function () {
        const title = this.data.selectedItem.textContent;
    
        wx.setClipboardData({
          data: title,
          success: function (res) {
            wx.showToast({
              title: '标题已复制',
              icon: 'success',
            });
          },
          fail: function (res) {
            wx.showToast({
              title: '复制失败',
              icon: 'none',
            });
          },
        });
      },  
          onLoad: function () {
            wx.setNavigationBarTitle({
                title: '哔哩哔哩'
              });
              var items=this.data.items;
              for(var i=0;i<this.data.items.length;i++)
              {
                  var str=this.data.items[i].textContent;
                  if(str.length>12)
                  {
                      var new_str=str.substr(0,12)+'......';
                      items[i].textContent=new_str;
                  }
              }
              this.setData({
                  items:items
              })
        },
      
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})