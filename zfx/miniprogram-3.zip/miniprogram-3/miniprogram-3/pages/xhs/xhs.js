// pages/bdtb/bdtb.js
Page({
    data: {
        showBottomPopup: false,
        items: [
            { textContent: '文字介绍我哦我我容我我我我',_url:'http',pageview:0,writer:"未知"}
          ],
          selectedIndex: -1,
          selectedItem:[]
      },
        // 点击按钮显示底部小界面
    showBottomPopup: function (event) {
        const index = event.currentTarget.dataset.index;
        const selectedItem = this.data.items[index];
        this.setData({
        showBottomPopup: true,
        selectedIndex: index, 
        selectedItem:selectedItem,
        });
    },
    hideBottomPopup: function () {
        this.setData({
          showBottomPopup: false,
        selectedIndex: -1, // 重置 selectedIndex
        selectedItem: {}, // 重置选中的项数据
        });
      },
      copyUrl: function () {
        const url = this.data.selectedItem._url;
    
        wx.setClipboardData({
          data: url,
          success: function (res) {
            wx.showToast({
              title: '链接已复制',
              icon: 'success',
            });
          },
          fail: function (res) {
            wx.showToast({
              title: '复制失败',
              icon: 'none',
            });
          },
        });
      },  
          onLoad: function () {
            wx.setNavigationBarTitle({
                title: '小红书'
              });
              var items=this.data.items;
              for(var i=0;i<this.data.items.length;i++)
              {
                  var str=this.data.items[i].textContent;
                  if(str.length>12)
                  {
                      var new_str=str.substr(0,12)+'......';
                      items[i].textContent=new_str;
                  }
              }
              this.setData({
                  items:items
              })
        },
      
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})