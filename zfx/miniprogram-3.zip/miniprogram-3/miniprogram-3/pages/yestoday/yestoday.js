// pages/yestoday/yestoday.js
Page({

    data: {
        search_txt:"",
        imageUrls: [
            'http://i2.hdslb.com/bfs/archive/c4b294fb62693773434f1e02db505405ad16fb0b.jpg','http://i2.hdslb.com/bfs/archive/8870bc7b7e87c3deb2394e61f4f18e24f2cf85e4.jpg','http://i0.hdslb.com/bfs/archive/5dc141195a044c564231cbc109ad631d2280f466.jpg'
        ],
        currentIndex: 0
    },
    swiperChange: function (e) {
        this.setData({
          currentIndex: e.detail.current
        });
    },
    get_search:function(e) {
        var inputValue=e.detail.value;
        this.setData({search_txt:inputValue});
    },
    test:function () {
        console.log(this.data.currentIndex);
    },
    onLoad(options) {

    },
    onReady() {

    },
    onShow() {

    },


    onHide() {

    },

    onUnload() {

    },

    onPullDownRefresh() {

    },
    onReachBottom() {

    },

    onShareAppMessage() {

    }
})