// pages/history/history.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        items: [
            { imageSrc: 'http://picnew7.photophoto.cn/20130517/qiutiandeshulintupian-11483850_1.jpg', textContent: '文字介绍内容1',_url:'' ,pageview:0,writer:'未知'},
            {imageSrc: 'http://picnew7.photophoto.cn/20130517/qiutiandeshulintupian-11483850_1.jpg', textContent: '文字介绍内容2',_url:'' ,pageview:0,writer:'未知'},
            {imageSrc: 'http://picnew7.photophoto.cn/20130517/qiutiandeshulintupian-11483850_1.jpg', textContent: '文字介绍内容3',_url:'' ,pageview:0,writer:'未知'},
          ]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        wx.setNavigationBarTitle({
          title:'历史热搜',
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})