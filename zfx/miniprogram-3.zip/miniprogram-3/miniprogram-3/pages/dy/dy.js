// pages/bdtb/bdtb.js
Page({
    data: {
        showBottomPopup: false,
        items: [
            { textContent: '李佳琦团队回应双11收入250亿事实上事实上事实上飒飒飒',_url:'https://www.douyin.com/search/李佳琦团队回应双11收入250亿',pageview:11630535,writer:"未知"},
            { textContent: '知情人称缅北电诈成员劝降视频属实',_url:'https://www.douyin.com/search/知情人称缅北电诈成员劝降视频属实',pageview:10900649,writer:"未知"},
            { textContent: '西南地区再获高产油气井',_url:'https://www.douyin.com/search/西南地区再获高产油气井',pageview:9551677,writer:"未知"},
            { textContent: '河沟里捞的鱼苗能养活吗',_url:'https://www.douyin.com/search/河沟里捞的鱼苗能养活吗',pageview:9526492,writer:"未知"},
            { textContent: '猫：听我的这牌早胡了',_url:'https://www.douyin.com/search/猫：听我的这牌早胡了',pageview:9524398,writer:"未知"},
            { textContent: '第一视角rua东北虎',_url:'https://www.douyin.com/search/第一视角rua东北虎',pageview:9494033,writer:"未知"},
            { textContent: '泉州洛江原区长就餐时落水身亡',_url:'https://www.douyin.com/search/管理人员回应董事长跳楼身亡',pageview:8619501,writer:"未知"},
            { textContent: '官方通报周大生老凤祥员工互殴',_url:'https://www.douyin.com/search/官方通报周大生老凤祥员工互殴',pageview:8563736,writer:"未知"},
            { textContent: '为什么一穿高领就浑身难受',_url:'https://www.douyin.com/search/为什么一穿高领就浑身难受',pageview:8509833,writer:"未知"},
            { textContent: '闺蜜与敌蜜上KTV了',_url:'https://www.douyin.com/search/闺蜜与敌蜜上KTV了',pageview:8508597,writer:"未知"},
            { textContent: 'All Eyes On Me舞蹈挑战',_url:'https://www.douyin.com/search/All Eyes On Me舞蹈挑战',pageview:8453738,writer:"未知"},
            { textContent: '以爱为营郑书意人间清醒',_url:'https://www.douyin.com/search/以爱为营郑书意人间清醒',pageview:8378093,writer:"未知"},
            { textContent: '申京对抗约基奇',_url:'https://www.douyin.com/search/申京对抗约基奇',pageview:8361384,writer:"未知"},
            { textContent: '矿山安全监察局约谈十堰负责人',_url:'https://www.douyin.com/search/矿山安全监察局约谈十堰负责人',pageview:8330251,writer:"未知"},

          ],
        
          selectedIndex: -1,
          selectedItem:[]
      },
        // 点击按钮显示底部小界面
    showBottomPopup: function (event) {
        const index = event.currentTarget.dataset.index;
        const selectedItem = this.data.items[index];
        this.setData({
        showBottomPopup: true,
        selectedIndex: index, 
        selectedItem:selectedItem,
        });
    },
    copyTitle: function () {
        const title = this.data.selectedItem.textContent;
    
        wx.setClipboardData({
          data: title,
          success: function (res) {
            wx.showToast({
              title: '标题已复制',
              icon: 'success',
            });
          },
          fail: function (res) {
            wx.showToast({
              title: '复制失败',
              icon: 'none',
            });
          },
        });
      },  
    hideBottomPopup: function () {
        this.setData({
          showBottomPopup: false,
        selectedIndex: -1, // 重置 selectedIndex
        selectedItem: {}, // 重置选中的项数据
        });
      },
      copyUrl: function () {
        const url = this.data.selectedItem._url;
    
        wx.setClipboardData({
          data: url,
          success: function (res) {
            wx.showToast({
              title: '链接已复制',
              icon: 'success',
            });
          },
          fail: function (res) {
            wx.showToast({
              title: '复制失败',
              icon: 'none',
            });
          },
        });
      },  
          onLoad: function () {
            wx.setNavigationBarTitle({
                title: '抖音'
              });
              var items=this.data.items;
              for(var i=0;i<this.data.items.length;i++)
              {
                  var str=this.data.items[i].textContent;
                  if(str.length>16)
                  {
                      var new_str=str.substr(0,16)+'......';
                      items[i].textContent=new_str;
                  }
              }
              this.setData({
                  items:items
              })
        },
      
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})