// pages/bdtb/bdtb.js
Page({
    data: {
        showBottomPopup: false,
        items: [
            { imageSrc: 'https://tiebapic.baidu.com/forum/whfpf%3D84%2C88%2C40%3Bq%3D90/sign=4fc30e178efcc3ceb4959a73f478eebc/8b82b9014a90f6037b5e1e727f12b31bb051ed1d.jpg?tbpicau=2023-11-15-0_54a86b139b8237d2fb9fa9a3405e7f25', textContent: '清算时刻！LPL韩援打分',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20392592topic_name=%E6%B8%85%E7%AE%97%E6%97%B6%E5%88%BB%EF%BC%81LPL%E9%9F%A9%E6%8F%B4%E6%89%93%E5%88%86',pageview:1802000,writer:"未知"},
            { imageSrc: '', textContent: '缅甸果敢四大家族成员忏悔视频',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20398663&topic_name=%E7%BC%85%E7%94%B8%E6%9E%9C%E6%95%A2%E5%9B%9B%E5%A4%A7%E5%AE%B6%E6%97%8F%E6%88%90%E5%91%98%E5%BF%8F%E6%82%94%E8%A7%86%E9%A2%91',pageview:1786000,writer:"未知"},
            { imageSrc: '', textContent: '相亲65个女生终于上岸了',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20392693&topic_name=%E7%9B%B8%E4%BA%B265%E4%B8%AA%E5%A5%B3%E7%94%9F%E7%BB%88%E4%BA%8E%E4%B8%8A%E5%B2%B8%E4%BA%86',pageview:1325000,writer:"未知"},
            { imageSrc: '', textContent: '高校贴吧头像东方化异变',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20406596&topic_name=%E9%AB%98%E6%A0%A1%E8%B4%B4%E5%90%A7%E5%A4%B4%E5%83%8F%E4%B8%9C%E6%96%B9%E5%8C%96%E5%BC%82%E5%8F%98',pageview:1022000,writer:"未知"},
            { imageSrc: '', textContent: '假如WBG夺冠',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20412219&topic_name=%E5%81%87%E5%A6%82WBG%E5%A4%BA%E5%86%A0',pageview:863000,writer:"未知"},
            { imageSrc: '', textContent: '航吧口吧都看的人是什么成分',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20408513&topic_name=%E8%88%AA%E5%90%A7%E5%8F%A3%E5%90%A7%E9%83%BD%E7%9C%8B%E7%9A%84%E4%BA%BA%E6%98%AF%E4%BB%80%E4%B9%88%E6%88%90%E5%88%86',pageview:811000,writer:"未知"},
            { imageSrc: '', textContent: '人在美国 你问我答',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20408363&topic_name=%E4%BA%BA%E5%9C%A8%E7%BE%8E%E5%9B%BD%20%E4%BD%A0%E9%97%AE%E6%88%91%E7%AD%94',pageview:640000,writer:"未知"},
            { imageSrc: '', textContent: '如何评价新番《药屋少女的呢喃》',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20413421&topic_name=%E5%A6%82%E4%BD%95%E8%AF%84%E4%BB%B7%E6%96%B0%E7%95%AA%E3%80%8A%E8%8D%AF%E5%B1%8B%E5%B0%91%E5%A5%B3%E7%9A%84%E5%91%A2%E5%96%83%E3%80%8B',pageview:62500,writer:"未知"},
            { imageSrc: '', textContent: '博主爆料Ti预选赛打假赛',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20397388&topic_name=%E5%8D%9A%E4%B8%BB%E7%88%86%E6%96%99Ti%E9%A2%84%E9%80%89%E8%B5%9B%E6%89%93%E5%81%87%E8%B5%9B',pageview:591000,writer:"未知"},
            { imageSrc: '', textContent: '与世界逆行指数',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20412351&topic_name=%E4%B8%8E%E4%B8%96%E7%95%8C%E9%80%86%E8%A1%8C%E6%8C%87%E6%95%B0',pageview:580000,writer:"未知"},
            { imageSrc: '', textContent: 'WBG vs T1几几开',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20386190&topic_name=WBG%20vs%20T1%E5%87%A0%E5%87%A0%E5%BC%80',pageview:540000,writer:"未知"},
            { imageSrc: '', textContent: '如何评价Homme对369的使用方式',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20403976&topic_name=%E5%A6%82%E4%BD%95%E8%AF%84%E4%BB%B7Homme%E5%AF%B9369%E7%9A%84%E4%BD%BF%E7%94%A8%E6%96%B9%E5%BC%8F',pageview:516000,writer:"未知"},
            { imageSrc: '', textContent: '日本部分居民血检异常',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20402342&topic_name=%E6%97%A5%E6%9C%AC%E9%83%A8%E5%88%86%E5%B1%85%E6%B0%91%E8%A1%80%E6%A3%80%E5%BC%82%E5%B8%B8',pageview:418000,writer:"未知"},
            { imageSrc: '', textContent: '斗破苍穹真人版电影定档',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20403527&topic_name=%E6%96%97%E7%A0%B4%E8%8B%8D%E7%A9%B9%E7%9C%9F%E4%BA%BA%E7%89%88%E7%94%B5%E5%BD%B1%E5%AE%9A%E6%A1%A3',pageview:341000,writer:"未知"},
          ],
          items_copy: [
            { imageSrc: '', textContent: '清算时刻！LPL韩援打分',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20392592topic_name=%E6%B8%85%E7%AE%97%E6%97%B6%E5%88%BB%EF%BC%81LPL%E9%9F%A9%E6%8F%B4%E6%89%93%E5%88%86',pageview:1802000,writer:"未知"},
            { imageSrc: '', textContent: '缅甸果敢四大家族成员忏悔视频',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20398663&topic_name=%E7%BC%85%E7%94%B8%E6%9E%9C%E6%95%A2%E5%9B%9B%E5%A4%A7%E5%AE%B6%E6%97%8F%E6%88%90%E5%91%98%E5%BF%8F%E6%82%94%E8%A7%86%E9%A2%91',pageview:1786000,writer:"未知"},
            { imageSrc: '', textContent: '相亲65个女生终于上岸了',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20392693&topic_name=%E7%9B%B8%E4%BA%B265%E4%B8%AA%E5%A5%B3%E7%94%9F%E7%BB%88%E4%BA%8E%E4%B8%8A%E5%B2%B8%E4%BA%86',pageview:1325000,writer:"未知"},
            { imageSrc: '', textContent: '高校贴吧头像东方化异变',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20406596&topic_name=%E9%AB%98%E6%A0%A1%E8%B4%B4%E5%90%A7%E5%A4%B4%E5%83%8F%E4%B8%9C%E6%96%B9%E5%8C%96%E5%BC%82%E5%8F%98',pageview:1022000,writer:"未知"},
            { imageSrc: '', textContent: '假如WBG夺冠',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20412219&topic_name=%E5%81%87%E5%A6%82WBG%E5%A4%BA%E5%86%A0',pageview:863000,writer:"未知"},
            { imageSrc: '', textContent: '航吧口吧都看的人是什么成分',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20408513&topic_name=%E8%88%AA%E5%90%A7%E5%8F%A3%E5%90%A7%E9%83%BD%E7%9C%8B%E7%9A%84%E4%BA%BA%E6%98%AF%E4%BB%80%E4%B9%88%E6%88%90%E5%88%86',pageview:811000,writer:"未知"},
            { imageSrc: '', textContent: '人在美国 你问我答',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20408363&topic_name=%E4%BA%BA%E5%9C%A8%E7%BE%8E%E5%9B%BD%20%E4%BD%A0%E9%97%AE%E6%88%91%E7%AD%94',pageview:640000,writer:"未知"},
            { imageSrc: '', textContent: '如何评价新番《药屋少女的呢喃》',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20413421&topic_name=%E5%A6%82%E4%BD%95%E8%AF%84%E4%BB%B7%E6%96%B0%E7%95%AA%E3%80%8A%E8%8D%AF%E5%B1%8B%E5%B0%91%E5%A5%B3%E7%9A%84%E5%91%A2%E5%96%83%E3%80%8B',pageview:62500,writer:"未知"},
            { imageSrc: '', textContent: '博主爆料Ti预选赛打假赛',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20397388&topic_name=%E5%8D%9A%E4%B8%BB%E7%88%86%E6%96%99Ti%E9%A2%84%E9%80%89%E8%B5%9B%E6%89%93%E5%81%87%E8%B5%9B',pageview:591000,writer:"未知"},
            { imageSrc: '', textContent: '与世界逆行指数',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20412351&topic_name=%E4%B8%8E%E4%B8%96%E7%95%8C%E9%80%86%E8%A1%8C%E6%8C%87%E6%95%B0',pageview:580000,writer:"未知"},
            { imageSrc: '', textContent: 'WBG vs T1几几开',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20386190&topic_name=WBG%20vs%20T1%E5%87%A0%E5%87%A0%E5%BC%80',pageview:540000,writer:"未知"},
            { imageSrc: '', textContent: '如何评价Homme对369的使用方式',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20403976&topic_name=%E5%A6%82%E4%BD%95%E8%AF%84%E4%BB%B7Homme%E5%AF%B9369%E7%9A%84%E4%BD%BF%E7%94%A8%E6%96%B9%E5%BC%8F',pageview:516000,writer:"未知"},
            { imageSrc: '', textContent: '日本部分居民血检异常',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20402342&topic_name=%E6%97%A5%E6%9C%AC%E9%83%A8%E5%88%86%E5%B1%85%E6%B0%91%E8%A1%80%E6%A3%80%E5%BC%82%E5%B8%B8',pageview:418000,writer:"未知"},
            { imageSrc: '', textContent: '斗破苍穹真人版电影定档',_url:'https://tieba.baidu.com/hottopic/browse/hottopic?topic_id=20403527&topic_name=%E6%96%97%E7%A0%B4%E8%8B%8D%E7%A9%B9%E7%9C%9F%E4%BA%BA%E7%89%88%E7%94%B5%E5%BD%B1%E5%AE%9A%E6%A1%A3',pageview:341000,writer:"未知"},
          ],
          selectedIndex: -1,
          selectedItem:[]
      },
        // 点击按钮显示底部小界面
    showBottomPopup: function (event) {
        const index = event.currentTarget.dataset.index;
        const selectedItem = this.data.items_copy[index];
        this.setData({
        showBottomPopup: true,
        selectedIndex: index, 
        selectedItem:selectedItem,
        });
    },
    hideBottomPopup: function () {
        this.setData({
          showBottomPopup: false,
        selectedIndex: -1, // 重置 selectedIndex
        selectedItem: {}, // 重置选中的项数据
        });
      },
      copyUrl: function () {
        const url = this.data.selectedItem._url;
    
        wx.setClipboardData({
          data: url,
          success: function (res) {
            wx.showToast({
              title: '链接已复制',
              icon: 'success',
            });
          },
          fail: function (res) {
            wx.showToast({
              title: '复制失败',
              icon: 'none',
            });
          },
        });
      },  
          onLoad: function () {
            wx.setNavigationBarTitle({
                title: '百度贴吧'
              });
              var items=this.data.items;
              for(var i=0;i<this.data.items.length;i++)
              {
                  var str=this.data.items[i].textContent;
                  if(str.length>12)
                  {
                      var new_str=str.substr(0,12)+'......';
                      items[i].textContent=new_str;
                  }
              }
              this.setData({
                  items:items
              })
        },
      
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})